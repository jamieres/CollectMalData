#!/usr/bin/env python
# -*- coding: utf-8 -*-
__description__ = "For collect malicious domains. Part of CollectMalData set."
__version__ = "1.0"
__contact__ = "jamieres-[at]-gmail-[dot]-com"

import sys,os,re,time,colorama
from contextlib import closing
from urllib import urlopen
from colorama import Fore, Style, init
init()

try:
    os.remove('maliciousdomain')
except OSError:
    pass 

 
eso = open("cleandomlist", "w+")

domlist = ["https://zeustracker.abuse.ch/blocklist.php?download=domainblocklist","https://isc.sans.edu/feeds/suspiciousdomains_Low.txt","https://isc.sans.edu/feeds/suspiciousdomains_Medium.txt","https://isc.sans.edu/feeds/suspiciousdomains_High.txt","http://osint.bambenekconsulting.com/feeds/c2-dommasterlist.txt","http://hosts-file.net/.%5Cad_servers.txt","http://mirror1.malwaredomains.com/files/justdomains","https://ransomwaretracker.abuse.ch/downloads/RW_DOMBL.txt","http://www.malwaredomainlist.com/mdlcsv.php?inactive=off","https://pgl.yoyo.org/adservers/serverlist.php","https://raw.githubusercontent.com/Dawsey21/Lists/master/adblock-list.txt","https://s3.amazonaws.com/lists.disconnect.me/simple_malvertising.txt","https://s3.amazonaws.com/lists.disconnect.me/simple_malware.txt","http://securemecca.com/Downloads/hosts.txt","https://raw.githubusercontent.com/azet12/KADhosts/master/KADhosts.txt"]

for doms in domlist:
        copy = urlopen(doms)
        dom = []
        count = 0
        start = time.time()
        print "\n From %s..." % (doms)

        with closing(copy):
            for dompage in copy.readlines():
                   dompage = dompage.rstrip()
                   domregex = re.findall(r'(?:[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*\.)+[a-z]{2,10}', dompage)
                   if domregex is not None and domregex not in dom:
                       dom.append(domregex)

            for baddom in dom:
                   domad = "".join(baddom)
                   if domad is not "":
                    count = count+1
                    eso.write(domad)
                    eso.write("\n")
            eso.write("\n")
        end = time.time()
        print Fore.YELLOW + Style.BRIGHT + "   Saved %s Domains." %(count) + Fore.WHITE + Style.NORMAL
eso.close()

lines_seen = set() 
outfile = open("maliciousdomain", "w+")
for line in open("cleandomlist", "r"):
    if line not in lines_seen: 
        outfile.write(line)
        lines_seen.add(line)
outfile.close()

with open("cleandomlist") as ucdoms:
    ucbaddoms = sum(1 for _ in ucdoms)

with open("maliciousdomain") as dom:
    maldom = sum(1 for _ in dom)
dupedom = (ucbaddoms-maldom)

print Fore.YELLOW + Style.BRIGHT + "\n\t%s duplicate malicious Domains removed." %dupedom
print "\t%s bad Domains saved in file maliciousdomain. Please, check it." % maldom
os.remove("cleandomlist")