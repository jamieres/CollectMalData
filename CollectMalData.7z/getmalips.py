#!/usr/bin/env python
# -*- coding: utf-8 -*-

__description__ = "For collect malicious ips. Part of CollectMalData set."
__version__ = "1.0"
__contact__ = "jamieres-[at]-gmail-[dot]-com"

import sys,os,re,time,colorama
from contextlib import closing
from urllib import urlopen
from colorama import Fore, Style, init
init()

try:
    os.remove("maliciousip")
except OSError:
    pass 
 
eso = open("cleaniplist", "w+")

iplist = ["http://rules.emergingthreats.net/blockrules/compromised-ips.txt","https://rules.emergingthreats.net/fwrules/emerging-Block-IPs.txt",
"http://www.blocklist.de/lists/bruteforcelogin.txt","http://biesiekierz.eu/errors/blacklist.txt","https://myip.ms/files/blacklist/csf/latest_blacklist_users_submitted.txt","https://myip.ms/files/blacklist/csf/latest_blacklist.txt","https://sblam.com/blacklist.txt","http://www.openbl.org/lists/base.txt","http://www.nothink.org/blacklist/blacklist_malware_http.txt","http://www.nothink.org/blacklist/blacklist_ssh_all.txt","http://antispam.imp.ch/spamlist","http://malc0de.com/bl/IP_Blacklist.txt","http://hosts-file.net/rss.asp","https://feodotracker.abuse.ch/blocklist/?download=ipblocklist","http://www.binarydefense.com/banlist.txt","http://reputation.alienvault.com/reputation.data","https://lists.blocklist.de/lists/bruteforcelogin.txt","https://lists.blocklist.de/lists/bots.txt","https://zeustracker.abuse.ch/blocklist.php?download=ipblocklist","https://zeustracker.abuse.ch/blocklist.php?download=badips","http://www.malwaredomainlist.com/hostslist/ip.txt","https://sslbl.abuse.ch/blacklist/sslipblacklist.csv","https://sslbl.abuse.ch/blacklist/sslipblacklist_aggressive.csv","https://sslbl.abuse.ch/blacklist/dyre_sslipblacklist_aggressive.csv","https://ransomwaretracker.abuse.ch/downloads/RW_IPBL.txt","https://www.spamhaus.org/drop/drop.txt","https://www.spamhaus.org/drop/edrop.txt","https://feodotracker.abuse.ch/blocklist/?download=ipblocklist","https://pgl.yoyo.org/adservers/iplist.php"] 

for ips in iplist:
        copy = urlopen(ips)
        ip = []
        count = 0
        start = time.time()
        print "\n From %s..." % (ips)
        with closing(copy):
            for iptext in copy.readlines():
                   iptext = iptext.rstrip()
                   ipregex = re.findall(r"(?:\d{1,3}\.){3}\d{1,3}", iptext)
                   if ipregex is not None and ipregex not in ip:
                       ip.append(ipregex)

            for badip in ip:
                   ipaddress = "".join(badip)
                   if ipaddress is not "":
                    count = count+1
                    eso.write(ipaddress)
                    eso.write("\n")
            eso.write("\n")
        end = time.time()
        print Fore.GREEN + "   Saved %s IPs." %(count) + Fore.WHITE + Style.NORMAL
eso.close()

lines_seen = set() 
outfile = open("maliciousip", "w+")
for line in open("cleaniplist", "r"):
    if line not in lines_seen: 
        outfile.write(line)
        lines_seen.add(line)
outfile.close()

with open("cleaniplist") as ucips:
    ucbadips = sum(1 for _ in ucips)

with open("maliciousip") as ip:
    malip = sum(1 for _ in ip)
dupeip = (ucbadips-malip)

print Fore.GREEN + "\n\t%s duplicate malicious IPs removed." %dupeip
print "\t%s bad IPs saved in file maliciousip. Please, check it." % malip
os.remove("cleaniplist")