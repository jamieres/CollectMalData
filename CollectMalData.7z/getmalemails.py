#!/usr/bin/env python
# -*- coding: utf-8 -*-
__description__ = "For collect malicious emails. Part of CollectMalData set."
__version__ = "1.0"
__contact__ = "jamieres-[at]-gmail-[dot]-com"

import sys,os,re,time,colorama
from contextlib import closing
from urllib import urlopen
from colorama import Fore, Style, init
init()

try:
    os.remove('maliciousemail')
except OSError:
    pass 

 
eso = open("cleanemaillist", "w+")

emllist = ["http://www.koalicia.genliga.ru/grafica/spam.txt","http://klabs.org/mapld04/admin/spam/spam.txt","http://www.redballoon.net/~snorwood/spam.txt","https://sslbl.abuse.ch/blacklist/sslipblacklist_aggressive.csv","http://child-abuse.com/docs/bademail.txt"]


for emls in emllist:
        copy = urlopen(emls)
        eml = []
        count = 0
        start = time.time()
        print "\n From %s..." % (emls)

        with closing(copy):
            for emlpage in copy.readlines():
                   emlpage = emlpage.rstrip()
                   emlregex = re.findall("[a-zA-Z0-9+_\-\.]+@[0-9a-zA-Z][.-0-9a-zA-Z]*.[a-zA-Z]+", emlpage)
                   if emlregex is not None and emlregex not in eml:
                       eml.append(emlregex)

            for bademl in eml:
                   emladdress = "".join(bademl)
                   if emladdress is not "":
                    count = count+1
                    eso.write(emladdress)
                    eso.write("\n")
            eso.write("\n")
        end = time.time()
        print Fore.MAGENTA + Style.BRIGHT + "   Saved %s Emails." %(count) + Fore.WHITE + Style.NORMAL
eso.close()

lines_seen = set() 
outfile = open("maliciousemail", "w+")
for line in open("cleanemaillist", "r"):
    if line not in lines_seen: 
        outfile.write(line)
        lines_seen.add(line)
outfile.close()

with open("cleanemaillist") as ucemls:
    ucbademls = sum(1 for _ in ucemls)

with open("maliciousemail") as eml:
    maleml = sum(1 for _ in eml)
dupeeml = (ucbademls-maleml)

print Fore.MAGENTA + Style.BRIGHT + "\n\t%s duplicate malicious Emails removed." %dupeeml
print "\t%s bad Emails saved in file maliciousemail. Please, check it." % maleml
os.remove("cleanemaillist")