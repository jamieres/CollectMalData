#!/usr/bin/env python
# -*- coding: utf-8 -*-
__description__ = "For collect malicious urls. Part of CollectMalData set."
__version__ = "1.0"
__contact__ = "jamieres-[at]-gmail-[dot]-com"

import sys,os,re,time,colorama
from contextlib import closing
from urllib import urlopen
from colorama import Fore, Style, init
init()

try:
    os.remove("maliciousurl")
except OSError:
    pass 

 
eso = open("cleanurllist", "w+")

urllist = ["http://malwareurls.joxeankoret.com/normal.txt","https://openphish.com/feed.txt","https://ransomwaretracker.abuse.ch/downloads/RW_URLBL.txt", "http://vxvault.net/URL_List.php","http://cybercrime-tracker.net/ccam_rss.php"] 

for urls in urllist:
        copy = urlopen(urls)
        url = []
        count = 0
        start = time.time()
        print "\n From %s..." % (urls)

        with closing(copy):
            for page in copy.readlines():
                   page = page.rstrip()
                   urlregex = re.findall("http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+", page)
                   if urlregex is not None and urlregex not in url:
                       url.append(urlregex)

            for badurl in url:
                   ipaddress = "".join(badurl)
                   if ipaddress is not "":
                    count = count+1
                    eso.write(ipaddress)
                    eso.write("\n")
            eso.write("\n")
        end = time.time()
        print Fore.CYAN + Style.BRIGHT +"   Saved %s URLs." %(count) + Fore.WHITE + Style.NORMAL
eso.close()

lines_seen = set() 
outfile = open("maliciousurl", "w+")
for line in open("cleanurllist", "r"):
    if line not in lines_seen: 
        outfile.write(line)
        lines_seen.add(line)
outfile.close()

with open("cleanurllist") as ucips:
    ucbadips = sum(1 for _ in ucips)

with open("maliciousurl") as url:
    malurl = sum(1 for _ in url)
dupeurl = (ucbadips-malurl)

print Fore.CYAN + Style.BRIGHT + "\n\t%s duplicate malicious URLs removed." %dupeurl
print "\t%s bad URLs saved in file maliciousurl. Please, check it." % malurl
os.remove("cleanurllist")